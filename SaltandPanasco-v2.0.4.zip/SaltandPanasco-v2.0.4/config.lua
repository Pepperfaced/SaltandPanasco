return {
	G.GAME["disable_jokers"] = false,
	G.GAME["disable_spices"] = false,
	G.GAME["dark_mode"] = false
}